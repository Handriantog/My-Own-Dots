# Scoped Codex execution sessions

`createExecutionSession` is an additive, experimental coding API for the qualified macOS arm64 Codex CLI `0.163.0`. Existing inference and restricted provider-session APIs retain their contracts. The host must own project approval, tool authorization, durable task state and result presentation.

```js
import { createExecutionSession } from 'myown-llm-integrator';

// Obtain this canonical directory from an explicit owner execution grant.
const session = createExecutionSession({
  scope: { cwd: approvedCanonicalProject, access: 'execute' },
  instructions: 'Complete the authorized task and report observed evidence.',
});
try {
  await session.warm();
  const result = await session.run({
    input: authorizedConversation,
    signal,
    onEvent: event => persistExecutionEvent(event),
  });
  // completed means the model turn completed, not proof of an arbitrary goal.
  // cancelled is confirmed interruption; uncertain must never be replayed blindly.
  displayResult(result);
} finally {
  await session.close();
}
```

Omitting `scope` removes native execution environments. Legacy read/edit access is insufficient to supply an execution scope. The exact project directory and its filesystem identity are checked at startup and before each turn. The host must also invalidate its grant during execution when permission changes.

`warm()` checks the exact CLI version, subscription login, effective configuration and managed requirements before creating a thread. The executable is explicit `executable`, otherwise `env.CODEX_BIN`/`process.env.CODEX_BIN`, otherwise `codex` on PATH. Unsupported versions, API-key authentication and conflicting settings stop execution; there is no paid API or provider fallback.

Each `run({ input, signal, timeoutMs, onEvent })` starts a fresh ephemeral thread, accepts at most 1 MiB of authorized text, and returns `completed`, `failed`, `paused`, `cancelled` or `uncertain`, plus bounded evidence and correlation IDs. Only one turn can be active on a session. A dispatched turn is never automatically replayed. A lost process or unconfirmed cancellation makes its effects uncertain. `interrupt()` requests cancellation; inspect the eventual run result for confirmation. `close()` also reaps the process.

Host tools use `tools: [{ name, description, inputSchema }]` and `onTool({ name, arguments, callId, signal })`. Return `{ content: string, isError?: boolean, pause?: boolean }`. Validate arguments, check current authorization and persist admission before performing effects. A client approval request should return `pause: true` without claiming approval. The host can start a new session with the subsequently approved scope and canonical tool results; it must not repeat effects that already occurred. A callback that ignores cancellation can leave its own work uncertain; Integrator cannot undo external host effects.

Native commands receive platform-minimal reads, writes inside the approved project, an explicit denial of canonical Codex credential storage and no network access. The explicit denial also prevents inherited `allow` command rules from bypassing the sandbox in the pinned engine. Project configuration is pinned untrusted before thread startup, inherited MCP servers are disabled, and effective restrictions are checked. Native plugins, hooks, host skills, browser/computer tools and Node REPL are disabled. The embedded V8 code-mode dispatcher is enabled because the qualified model requires it; its module loader rejects imports.

The CLI itself uses its existing subscription credentials and network connection for inference. No credentials are copied, and owner configuration is not rewritten. Project commands cannot use that access. Native command evidence includes output/exit status when the engine supplies it; the pinned upstream engine does not emit a command item for every sandbox-rejected code-mode request. Do not treat absence of an event as success.

Qualification commands (disposable fixtures):

```sh
npm test
npm run test:python
npm run test:pack
node scripts/qualify-native-mcp.mjs "$PWD" /absolute/path/to/codex
node scripts/qualify-native-rules.mjs "$PWD" /absolute/path/to/codex
node scripts/qualify-execution.mjs --live
```

The first two native probes need no account or allowance; `--control` deliberately reproduces the prior unsafe configuration only inside their disposable fixture homes. The rule probe uses a loopback model-response fixture to exercise real native tool dispatch. Production sessions reject that endpoint override. The final live coding probe uses the existing subscription allowance. Qualification is specific to the tested version/platform; upgrading either requires repeating it.
